# CSS-Image-Hover-Effect


<img width="1382" alt="Screenshot 2022-06-03 at 16 24 42" src="https://user-images.githubusercontent.com/42389395/171884172-4d495a61-713c-4063-a4d3-03953e78c6b9.png">
